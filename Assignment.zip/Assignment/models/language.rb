class Language < ActiveRecord::Base
  belongs_to :resume
end
