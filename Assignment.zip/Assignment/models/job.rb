class Job < ActiveRecord::Base
  belongs_to :resume
end
