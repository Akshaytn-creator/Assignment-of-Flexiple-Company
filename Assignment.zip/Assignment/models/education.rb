class Education < ActiveRecord::Base
  belongs_to :resume
end
