class Project < ActiveRecord::Base
  belongs_to :resume
end
