module InterestsHelper
end
