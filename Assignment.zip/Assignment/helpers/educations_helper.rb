module EducationsHelper
end
